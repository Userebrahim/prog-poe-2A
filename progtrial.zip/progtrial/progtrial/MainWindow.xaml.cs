﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace progtrial
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private List<Recipe> recipes = new List<Recipe>();

        public MainWindow()
        {
            InitializeComponent();
        }

        private void AddIngredient_Click(object sender, RoutedEventArgs e)
        {
            IngredientWindow ingredientWindow = new IngredientWindow();
            ingredientWindow.Owner = this;
            ingredientWindow.ShowDialog();

            if (ingredientWindow.DialogResult.HasValue && ingredientWindow.DialogResult.Value)
            {
                Ingredient ingredient = ingredientWindow.Ingredient;
                lstIngredients.Items.Add(ingredient);
            }
        }

        private void AddStep_Click(object sender, RoutedEventArgs e)
        {
            StepWindow stepWindow = new StepWindow();
            stepWindow.Owner = this;
            stepWindow.ShowDialog();

            if (stepWindow.DialogResult.HasValue && stepWindow.DialogResult.Value)
            {
                string step = stepWindow.Step;
                lstSteps.Items.Add(step);
            }
        }

        private void AddRecipe_Click(object sender, RoutedEventArgs e)
        {
            Recipe recipe = new Recipe();
            recipe.Name = txtRecipeName.Text;
            recipe.Ingredients = lstIngredients.Items.Cast<Ingredient>().ToList();
            recipe.Steps = lstSteps.Items.Cast<string>().ToList();

            recipes.Add(recipe);
            lstRecipes.Items.Add(recipe);

            ClearAll_Click(null, null);
        }

        private void ClearAll_Click(object sender, RoutedEventArgs e)
        {
            txtRecipeName.Clear();
            lstIngredients.Items.Clear();
            lstSteps.Items.Clear();
        }

        private void lstRecipes_SelectionChanged(object sender, RoutedEventArgs e)
        {
            Recipe selectedRecipe = lstRecipes.SelectedItem as Recipe;
            if (selectedRecipe != null)
            {
                MessageBox.Show(
                    $"Recipe: {selectedRecipe.Name}\n\nIngredients:\n{string.Join("\n", selectedRecipe.Ingredients)}\n\nSteps:\n{string.Join("\n", selectedRecipe.Steps)}",
                    "Recipe Details",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information
                );
            }
        }
    }

    public class Recipe
    {
        public string Name { get; set; }
        public List<Ingredient> Ingredients { get; set; }
        public List<string> Steps { get; set; }

        public override string ToString()
        {
            return Name;
        }
    }

    public class Ingredient
    {
        public string Name { get; set; }
        public string Quantity { get; set; }
        public string Unit { get; set; }
        public int Calories { get; set; }
        public string FoodGroup { get; set; }

        public override string ToString()
        {
            return $"{Name}, {Quantity} {Unit}, {Calories} calories, {FoodGroup}";
        }
    }
}
